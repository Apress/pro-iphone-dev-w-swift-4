//
//  ViewController.swift
//  Text2Speech
//
//  Created by Wallace Wang on 10/18/17.
//  Copyright © 2017 Wallace Wang. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    @IBOutlet var textView: UITextView!
    @IBOutlet var rateSlider: UISlider!
    
 
    let audio = AVSpeechSynthesizer()
    var convertText = AVSpeechUtterance(string: "")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func readText(_ sender: UIButton) {
        convertText = AVSpeechUtterance(string: textView.text)
        convertText.rate = rateSlider.value
        audio.speak(convertText)
    }
    
}


