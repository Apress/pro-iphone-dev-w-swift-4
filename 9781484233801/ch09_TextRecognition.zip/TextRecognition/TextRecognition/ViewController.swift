//
//  ViewController.swift
//  TextRecognition
//
//  Created by Wallace Wang on 10/10/17.
//  Copyright © 2017 Wallace Wang. All rights reserved.
//

import UIKit
import Vision
import AVFoundation

class ViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {

    @IBOutlet var textImage: UIImageView!
    
    var session = AVCaptureSession()
    var requests = [VNRequest]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        getVideo()
        detectText()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func getVideo() {
        session.sessionPreset = AVCaptureSession.Preset.photo
        let camera = AVCaptureDevice.default(for: AVMediaType.video)
        
        let cameraInput = try! AVCaptureDeviceInput(device: camera!)
        let cameraOutput = AVCaptureVideoDataOutput()
        cameraOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: Int(kCVPixelFormatType_32BGRA)]
        cameraOutput.setSampleBufferDelegate(self, queue: DispatchQueue.global(qos: DispatchQoS.QoSClass.default))
        session.addInput(cameraInput)
        session.addOutput(cameraOutput)
        
        let videoLayer = AVCaptureVideoPreviewLayer(session: session)
        videoLayer.frame = textImage.bounds
        textImage.layer.addSublayer(videoLayer)
        session.startRunning()
    }
    
    func detectText() {
        let textRequest = VNDetectTextRectanglesRequest(completionHandler: handleText)
        textRequest.reportCharacterBoxes = true
        requests = [textRequest]
    }
    
    func handleText(request: VNRequest, error: Error?) {
        guard let observations = request.results else {
            print ("No text found")
            return
        }
        
        let result = observations.map({$0 as? VNTextObservation})
        
        DispatchQueue.main.async() {
            self.textImage.layer.sublayers?.removeSubrange(1...)
            for region in result {
                guard let foundRegion = region else {
                    continue
                }
                
                self.identifyWords(box: foundRegion)
            }
        }
    }
    
    func identifyWords(box: VNTextObservation) {
        guard let rectangle = box.characterBoxes else {
            return
        }
        
        var maxX: CGFloat = 9999.0
        var minX: CGFloat = 0.0
        var maxY: CGFloat = 9999.0
        var minY: CGFloat = 0.0
        
        for char in rectangle {
            if char.bottomLeft.x < maxX {
                maxX = char.bottomLeft.x
            }
            if char.bottomRight.x > minX {
                minX = char.bottomRight.x
            }
            if char.bottomRight.y < maxY {
                maxY = char.bottomRight.y
            }
            if char.topRight.y > minY {
                minY = char.topRight.y
            }
        }
        
        let xCord = maxX * textImage.frame.size.width
        let yCord = (1 - minY) * textImage.frame.size.height
        let width = (minX - maxX) * textImage.frame.size.width
        let height = (minY - maxY) * textImage.frame.size.height
        
        let outline = CALayer()
        outline.frame = CGRect(x: xCord, y: yCord, width: width, height: height)
        outline.borderWidth = 2.0
        outline.borderColor = UIColor.red.cgColor
        
        textImage.layer.addSublayer(outline)
    }
    
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else {
            return
        }
        
        var requestOptions:[VNImageOption : Any] = [:]
        
        if let cameraData = CMGetAttachment(sampleBuffer, kCMSampleBufferAttachmentKey_CameraIntrinsicMatrix, nil) {
            requestOptions = [.cameraIntrinsics:cameraData]
        }
        
        let imageRequestHandler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: CGImagePropertyOrientation(rawValue: 6)!, options: requestOptions)
        
        do {
            try imageRequestHandler.perform(self.requests)
        } catch {
            print(error)
        }
    }
    
}

