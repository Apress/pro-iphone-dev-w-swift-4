//
//  ViewController.swift
//  Speech2Text
//
//  Created by Wallace Wang on 10/16/17.
//  Copyright © 2017 Wallace Wang. All rights reserved.
//

import UIKit
import Speech

class ViewController: UIViewController, SFSpeechRecognizerDelegate {
    
    @IBOutlet var recordButton: UIButton!
    @IBOutlet var textLabel: UILabel!
    @IBOutlet var stopButton: UIButton!
    
    let audioEngine = AVAudioEngine()
    let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    var request : SFSpeechAudioBufferRecognitionRequest? = nil
    var recognitionTask : SFSpeechRecognitionTask?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        stopButton.isEnabled = false
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func buttonTapped(_ sender: UIButton) {
        recordButton.isEnabled = false
        stopButton.isEnabled = true
        recognizeSpeech()
    }
    
    @IBAction func stopTapped(_ sender: UIButton) {
        recordButton.isEnabled = true
        stopButton.isEnabled = false
        stopRecording()
    }
    
    func stopRecording() {
        audioEngine.stop()
        request?.endAudio()
        recognitionTask?.cancel()
        audioEngine.inputNode.removeTap(onBus: 0)
        
    }
    
    func recognizeSpeech() {
        let node = audioEngine.inputNode
        
        request = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = request else {
            fatalError ("Can not create a recognition request")
        }
        
        recognitionRequest.shouldReportPartialResults = true
        
        let recordingFormat = node.outputFormat(forBus: 0)
        node.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, _) in
            self.request?.append(buffer)
        }
        
        audioEngine.prepare()
        do {
            try audioEngine.start()
        } catch {
            return print (error)
        }
        
        guard let recognizeMe = SFSpeechRecognizer() else {
            return
        }

        if !recognizeMe.isAvailable {
            return
        }
        
        recognitionTask = speechRecognizer?.recognitionTask(with: request!, resultHandler: {result, error in
            if let result = result {
                let transcribedString = result.bestTranscription.formattedString
                self.textLabel.text = transcribedString
                
                // Check for spoken command
                self.checkSpokenCommand(commandString: transcribedString)
                
            } else if let error = error {
                print(error)
            }
        })
        
    }
    
    func checkSpokenCommand (commandString: String) {
        switch commandString {
        case "Purple":
            textLabel.backgroundColor = UIColor.purple
        case "Green":
            textLabel.backgroundColor = UIColor.green
        case "Yellow":
            textLabel.backgroundColor = UIColor.yellow
        default:
            textLabel.backgroundColor = UIColor.white
        }
    }
    
}

