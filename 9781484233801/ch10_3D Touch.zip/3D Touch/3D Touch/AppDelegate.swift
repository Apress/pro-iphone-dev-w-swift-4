//
//  AppDelegate.swift
//  3D Touch
//
//  Created by Wallace Wang on 9/28/17.
//  Copyright © 2017 Wallace Wang. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    
    var launchedShortcutItem: UIApplicationShortcutItem?
    
    enum MenuItems: String {
        case First
        case Second
        case Third
        case Fourth
        
        init?(fullType: String) {
            guard let last = fullType.components(separatedBy: ".").last else { return nil }

            self.init(rawValue: last)
        }

        // MARK: Properties

        var type: String {
            return Bundle.main.bundleIdentifier! + ".\(self.rawValue)"
        }
    }
    
    func handleShortCutItem(_ shortcutItem: UIApplicationShortcutItem) -> Bool {
        var handled = false
        
        guard MenuItems(fullType: shortcutItem.type) != nil else {
            return false
        }
        
        guard let shortCutType = shortcutItem.type as String? else {
            return false
        }        
        
        switch (shortCutType) {
        case MenuItems.First.type:
            print ("View favorites")
            handled = true
        case MenuItems.Second.type:
            print ("Share")
            handled = true
        default:
            break
        }
        
        let alertController = UIAlertController(title: "Shortcut Chosen", message: "\"\(shortcutItem.localizedTitle)\"", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        window!.rootViewController?.present(alertController, animated: true, completion: nil)
        
        return handled
    }
    
    func application(_ application: UIApplication, performActionFor shortcutItem: UIApplicationShortcutItem, completionHandler: @escaping (Bool) -> Void) {
        
        completionHandler(handleShortCutItem(shortcutItem))
    }
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        // If a shortcut was launched, display its information and take the appropriate action
        if let shortcutItem = launchOptions?[UIApplicationLaunchOptionsKey.shortcutItem] as? UIApplicationShortcutItem {
            
            launchedShortcutItem = shortcutItem
        }
        
        
        // Install our two extra dynamic Quick Actions.
        if let shortcutItems = application.shortcutItems, shortcutItems.isEmpty {
            // Construct the items.

            let shortcut3 = UIMutableApplicationShortcutItem(type: MenuItems.Third.type, localizedTitle: "Play", localizedSubtitle: "Play audio", icon: UIApplicationShortcutIcon(type: .play)
            )
            
            let shortcut4 = UIMutableApplicationShortcutItem(type: MenuItems.Fourth.type, localizedTitle: "Add", localizedSubtitle: "Add an item", icon: UIApplicationShortcutIcon(type: .add)
            )

            // Update the application providing the initial 'dynamic' shortcut items.
            application.shortcutItems = [shortcut3, shortcut4]
        }
        
        return true
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }



    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


}

