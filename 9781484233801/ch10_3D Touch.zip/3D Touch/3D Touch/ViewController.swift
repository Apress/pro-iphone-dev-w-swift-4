//
//  ViewController.swift
//  3D Touch
//
//  Created by Wallace Wang on 9/28/17.
//  Copyright © 2017 Wallace Wang. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var forceLabel: UILabel!

 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        forceLabel.text = "Opening message"
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            if #available(iOS 9.0, *) {
                if traitCollection.forceTouchCapability == UIForceTouchCapability.available {
                    //print ("3D Touch available!")
                    let force = touch.force/touch.maximumPossibleForce
                    forceLabel.text = "\(force * 100)% force"
                } else {
                    print ("3D Touch not available")
                }
            } else {
                print ("Need iOS 9 or higher")
            }
        }
    }
    

    
}

