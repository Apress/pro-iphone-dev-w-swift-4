//
//  IntentHandler.swift
//  PayExtension
//
//  Created by Wallace Wang on 10/29/17.
//  Copyright © 2017 Wallace Wang. All rights reserved.
//

import Intents

class IntentHandler: INExtension, INSendPaymentIntentHandling {
    
    func handle(intent: INSendPaymentIntent, completion: @escaping (INSendPaymentIntentResponse) -> Void) {       
        let userActivity = NSUserActivity(activityType: NSStringFromClass(INSendMessageIntent.self))        
        completion(INSendPaymentIntentResponse(code: .success, userActivity: userActivity))
    }
    
    
    func confirm(intent: INSendPaymentIntent, completion: @escaping (INSendPaymentIntentResponse) -> Void) {
        let userActivity = NSUserActivity(activityType: NSStringFromClass(INSendPaymentIntent.self))
        let response = INSendPaymentIntentResponse(code: .ready, userActivity: userActivity)
        completion(response)
    }
    
    override func handler(for intent: INIntent) -> Any {
        // This is the default implementation.  If you want different objects to handle different intents,
        // you can override this and return the handler you want for that particular intent.
        
        return self
    }

}

