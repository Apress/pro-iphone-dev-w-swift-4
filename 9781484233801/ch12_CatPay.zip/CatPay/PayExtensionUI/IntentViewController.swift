//
//  IntentViewController.swift
//  PayExtensionUI
//
//  Created by Wallace Wang on 10/29/17.
//  Copyright © 2017 Wallace Wang. All rights reserved.
//

import IntentsUI

// As an example, this extension's Info.plist has been configured to handle interactions for INSendMessageIntent.
// You will want to replace this or add other intents as appropriate.
// The intents whose interactions you wish to handle must be declared in the extension's Info.plist.

// You can test this example integration by saying things to Siri like:
// "Send a message using <myApp>"

class IntentViewController: UIViewController, INUIHostedViewControlling, INUIHostedViewSiriProviding {
    
    @IBOutlet weak var contentLabel: UILabel!
    
    func configure(with interaction: INInteraction, context: INUIHostedViewContext, completion: @escaping ((CGSize) -> Void)) {
        
        if let paymentIntent = interaction.intent as? INSendPaymentIntent {
            
            guard let amount = paymentIntent.currencyAmount?.amount else {
                return completion(CGSize.zero)
            }
            
            let paymentDescription = "Sending \(amount) \(paymentIntent.currencyAmount?.currencyCode ?? "dollars") worth of cats"
            contentLabel.text = paymentDescription
        }
        completion(self.desiredSize)
    }
    
    var desiredSize: CGSize {
        return self.extensionContext!.hostedViewMaximumAllowedSize
    }
    
    var displaysPaymentTransaction: Bool {
        return true
    }
    
}
