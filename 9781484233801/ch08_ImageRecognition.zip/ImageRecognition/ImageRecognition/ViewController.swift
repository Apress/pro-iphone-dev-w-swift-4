//
//  ViewController.swift
//  ImageRecognition
//
//  Created by Wallace Wang on 9/18/17.
//  Copyright © 2017 Wallace Wang. All rights reserved.
//

import UIKit
import CoreML
import Vision

class ViewController: UIViewController {

    @IBOutlet var imageView: UIImageView!
    @IBOutlet var labelDescription: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let imagePath = Bundle.main.path(forResource: "cat", ofType: "jpg")
        let imageURL = NSURL.fileURL(withPath: imagePath!)
        
        let modelFile = MobileNet()
        let model = try! VNCoreMLModel(for: modelFile.model)
        
        let handler = VNImageRequestHandler(url: imageURL)
        let request = VNCoreMLRequest(model: model, completionHandler: findResults)
        
        try! handler.perform([request])
        // Do any additional setup after loading the view, typically from a nib.
    }

    func findResults(request: VNRequest, error: Error?) {
        guard let results = request.results as? [VNClassificationObservation] else {
            fatalError("Unable to get results")
        }
        
        var bestGuess = ""
        var bestConfidence: VNConfidence = 0
        
        for classification in results {
            if (classification.confidence > bestConfidence) {
                bestConfidence = classification.confidence
                bestGuess = classification.identifier
            }
        }
        
        labelDescription.text = "Image is: \(bestGuess) with confidence \(bestConfidence)) out of 1"
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

